# <--- paste the full Streamlit app code here --->

import streamlit as st
import pandas as pd
import numpy as np
import pickle
import os
import matplotlib.pyplot as plt
from datetime import datetime
import json

# ---------------- CONFIG ----------------
MODEL_PATH = "decision_tree_model.pkl"
FEATURES_JSON = "features_order.json"
USER_DB_CSV = "user_data.csv"   # local user DB file
# ----------------------------------------

st.set_page_config(page_title="Personalized Sleep Predictor", layout="centered")
st.title("😴 Personalized Sleep Health & Lifestyle Predictor")

# Ensure model & features exist
if not os.path.exists(MODEL_PATH):
    st.error(f"Model file '{MODEL_PATH}' not found. Run training script and place the file here.")
    st.stop()
if not os.path.exists(FEATURES_JSON):
    st.error(f"Features file '{FEATURES_JSON}' not found. Run training script and place the file here.")
    st.stop()

with open(MODEL_PATH, "rb") as f:
    model = pickle.load(f)

with open(FEATURES_JSON, "r") as f:
    FEATURE_ORDER = json.load(f)

# Mappings (must match training script)
BMI_LIST = ["Normal", "Overweight", "Obese", "Underweight"]
SLEEP_DISORDER_LIST = ["None", "Insomnia", "Sleep Apnea"]

# Create user DB if missing
if not os.path.exists(USER_DB_CSV):
    cols = ["user_name", "date"] + FEATURE_ORDER + ["Quality of Sleep", "source"]
    pd.DataFrame(columns=cols).to_csv(USER_DB_CSV, index=False)

# Sidebar: user identity
st.sidebar.header("User")
user_name = st.sidebar.text_input("Full name (unique)", "")
if user_name.strip():
    first_time_flag = st.sidebar.radio("Is this your first time here?", ("Yes", "No"))
else:
    st.sidebar.write("Enter your name to continue.")

def load_user_history(name):
    dfu = pd.read_csv(USER_DB_CSV)
    return dfu[dfu['user_name'].astype(str).str.strip().str.lower() == name.strip().lower()]

def append_user_record(rec_dict):
    dfu = pd.read_csv(USER_DB_CSV)
    df_new = pd.DataFrame([rec_dict])
    dfu = pd.concat([dfu, df_new], ignore_index=True)
    dfu.to_csv(USER_DB_CSV, index=False)

# If no name, prompt and exit
if not user_name.strip():
    st.info("Enter your full name in the sidebar to personalize the app.")
    st.stop()

# Friendly greeting
st.header(f"Hello, {user_name.split()[0].title()}!")

# FIRST-TIME USER FLOW
if first_time_flag == "Yes":
    st.subheader("First time setup — enter your data")
    with st.form("first_form"):
        gender = st.selectbox("Gender", ["Male", "Female"])
        bmi_cat = st.selectbox("BMI Category", BMI_LIST)
        sleep_disorder = st.selectbox("Sleep Disorder", SLEEP_DISORDER_LIST)
        age = st.number_input("Age (years)", 0, 120, 30)
        sleep_duration = st.number_input("Sleep Duration (hours last night)", 0.0, 24.0, 7.0, step=0.5)
        activity = st.number_input("Physical Activity (mins/day)", 0.0, 1440.0, 60.0)
        stress = st.slider("Stress Level (1–10)", 1, 10, 5)
        heart_rate = st.number_input("Heart Rate (bpm)", 30, 200, 70)
        steps = st.number_input("Daily Steps", 0, 200000, 5000)
        sys_bp = st.number_input("Systolic BP", 60, 250, 120)
        dia_bp = st.number_input("Diastolic BP", 30, 160, 80)
        submit = st.form_submit_button("Predict & Save")

    if submit:
        # prepare input in same order as FEATURE_ORDER
        feat_map = {
            "Gender_num": 1 if gender == "Male" else 0,
            "Age": age,
            "Sleep Duration": sleep_duration,
            "Physical Activity Level": activity,
            "Stress Level": stress,
            "BMI_cat": BMI_LIST.index(bmi_cat),
            "Heart Rate": heart_rate,
            "Daily Steps": steps,
            "SleepDis_cat": SLEEP_DISORDER_LIST.index(sleep_disorder),
            "Systolic BP": sys_bp,
            "Diastolic BP": dia_bp
        }

        # create DataFrame in feature order
        df_in = pd.DataFrame([[feat_map[c] for c in FEATURE_ORDER]], columns=FEATURE_ORDER)
        pred = model.predict(df_in)[0]

        st.success(f"Predicted Sleep Quality: **{pred}**")
        # save record
        rec = {"user_name": user_name, "date": datetime.now().strftime("%Y-%m-%d")}
        for c in FEATURE_ORDER:
            rec[c] = feat_map[c]
        rec["Quality of Sleep"] = pred
        rec["source"] = "predicted"
        append_user_record(rec)
        st.info("Your record has been saved to local user_data CSV.")

        # suggestions
        def give_suggestions(pred_val):
            try:
                pv = float(pred_val)
                if pv <= 2:
                    return [
                        "Predicted sleep quality is low. Consider consulting a doctor if this persists.",
                        "Improve sleep hygiene: consistent sleep times, avoid screens 1 hour before bed, reduce caffeine.",
                        "If daytime sleepiness or loud snoring present, seek medical evaluation (possible sleep apnea)."
                    ]
                elif pv <= 3:
                    return [
                        "Sleep quality is moderate. Try improving consistency of sleep schedule and reduce stress.",
                        "Increase daily physical activity (30 mins), maintain a cool/dark bedroom."
                    ]
                else:
                    return ["Sleep quality looks good. Keep healthy habits."]
            except:
                txt = str(pred_val).lower()
                if "poor" in txt or "bad" in txt:
                    return ["Predicted sleep quality appears poor. Consider medical advice if it persists."]
                return ["Keep tracking — maintain good sleep hygiene."]

        st.subheader("Suggestions")
        for s in give_suggestions(pred):
            st.write("•", s)

# RETURNING USER FLOW
else:
    st.subheader("Your history & next-day prediction")
    history = load_user_history(user_name)
    if history.empty:
        st.warning("We don't have previous records for this user. Switch to 'Yes' and enter your first record.")
    else:
        # show table (most recent first)
        history_sorted = history.sort_values("date", ascending=True)
        st.write("### Your saved history (most recent last)")
        st.dataframe(history_sorted)

        # plot histogram or line (if numeric)
        st.write("### Sleep quality histogram / trend")
        # try numeric conversion
        try:
            history_sorted["QualityNumeric"] = pd.to_numeric(history_sorted["Quality of Sleep"], errors="coerce")
            numeric_ok = history_sorted["QualityNumeric"].notna().any()
        except:
            numeric_ok = False

        fig, ax = plt.subplots()
        if numeric_ok:
            ax.plot(history_sorted["date"], history_sorted["QualityNumeric"], marker="o")
            ax.set_xlabel("Date")
            ax.set_ylabel("Sleep Quality (numeric)")
            plt.xticks(rotation=30)
        else:
            history_sorted["Quality of Sleep"].value_counts().plot(kind="bar", ax=ax)
            ax.set_ylabel("Count")
        st.pyplot(fig)

        # Let user optionally enter new today's inputs to predict next day
        st.write("---")
        st.write("Enter today's data to predict next-day sleep quality (this prediction will be saved):")
        with st.form("predict_next"):
            gender = st.selectbox("Gender", ["Male", "Female"])
            bmi_cat = st.selectbox("BMI Category", BMI_LIST)
            sleep_disorder = st.selectbox("Sleep Disorder", SLEEP_DISORDER_LIST)
            age = st.number_input("Age (years)", 0, 120, 30)
            sleep_duration = st.number_input("Sleep Duration (hours today)", 0.0, 24.0, 7.0, step=0.5)
            activity = st.number_input("Physical Activity (mins/day today)", 0.0, 1440.0, 60.0)
            stress = st.slider("Stress Level (1–10)", 1, 10, 5)
            heart_rate = st.number_input("Heart Rate (bpm)", 30, 200, 70)
            steps = st.number_input("Daily Steps", 0, 200000, 5000)
            sys_bp = st.number_input("Systolic BP", 60, 250, 120)
            dia_bp = st.number_input("Diastolic BP", 30, 160, 80)
            submitted = st.form_submit_button("Predict Next Day & Save")

        if submitted:
            feat_map = {
                "Gender_num": 1 if gender == "Male" else 0,
                "Age": age,
                "Sleep Duration": sleep_duration,
                "Physical Activity Level": activity,
                "Stress Level": stress,
                "BMI_cat": BMI_LIST.index(bmi_cat),
                "Heart Rate": heart_rate,
                "Daily Steps": steps,
                "SleepDis_cat": SLEEP_DISORDER_LIST.index(sleep_disorder),
                "Systolic BP": sys_bp,
                "Diastolic BP": dia_bp
            }
            df_in = pd.DataFrame([[feat_map[c] for c in FEATURE_ORDER]], columns=FEATURE_ORDER)
            pred = model.predict(df_in)[0]
            st.success(f"Predicted next-day sleep quality: **{pred}**")

            # Save record
            rec = {"user_name": user_name, "date": datetime.now().strftime("%Y-%m-%d")}
            for c in FEATURE_ORDER:
                rec[c] = feat_map[c]
            rec["Quality of Sleep"] = pred
            rec["source"] = "predicted"
            append_user_record(rec)
            st.info("Prediction saved to your local history.")

            # Suggestions
            def give_suggestions(pred_val):
                try:
                    pv = float(pred_val)
                    if pv <= 2:
                        return [
                            "Predicted sleep quality is low. Consider consulting a doctor if this persists.",
                            "Improve sleep hygiene: consistent schedule, avoid screens 1 hour before bed, reduce caffeine."
                        ]
                    elif pv <= 3:
                        return ["Sleep quality is moderate. Try small changes: consistent wake time, manage stress."]
                    else:
                        return ["Sleep quality looks good. Keep healthy habits!"]
                except:
                    return ["Keep tracking — maintain good sleep hygiene."]

            st.subheader("Suggestions")
            for s in give_suggestions(pred):
                st.write("•", s)
